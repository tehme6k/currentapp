-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2021 at 08:36 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `currentapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `retentions`
--

CREATE TABLE `retentions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `box_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `lot` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `retentions`
--

INSERT INTO `retentions` (`id`, `box_id`, `user_id`, `sub_category_id`, `start_date`, `lot`, `exp_date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1', 1, 1, '2021-03-01', '5620Q', '2021-03-01', '2021-03-01 09:28:15', '2021-03-01 09:28:15', NULL),
(2, '5', 1, 1, '2021-03-03', '123456789', '2021-03-03', '2021-03-03 13:01:16', '2021-03-03 13:01:16', NULL),
(3, '8', 1, 1, '2021-03-03', '258147369', '2021-03-03', '2021-03-03 13:06:51', '2021-03-03 13:06:51', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `retentions`
--
ALTER TABLE `retentions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `retentions`
--
ALTER TABLE `retentions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
